import os, statistics, secrets
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", secrets.token_hex(32))

database_url = os.environ.get("DATABASE_URL", "sqlite:///aviator.db")
if database_url.startswith("postgres://"):
    database_url = database_url.replace("postgres://", "postgresql://", 1)
app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Result(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    multiplier = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

class Prediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    predicted = db.Column(db.Float, nullable=False)
    low = db.Column(db.Float, nullable=False)
    high = db.Column(db.Float, nullable=False)
    confidence = db.Column(db.Integer, nullable=False)
    risk = db.Column(db.String(20), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        uid = session.get("user_id")
        user = db.session.get(User, uid) if uid else None
        if not user or not user.is_admin:
            flash("Admin access required.", "error")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def calculate_prediction(values):
    """Statistical estimate only; it cannot know the game's next server result."""
    if not values:
        return {"predicted": 2.00, "low": 1.20, "high": 3.50, "confidence": 20, "risk": "HIGH"}

    vals = values[-50:]
    median = statistics.median(vals)
    mean = statistics.fmean(vals)
    recent = vals[-10:]
    recent_mean = statistics.fmean(recent)
    volatility = statistics.pstdev(vals) if len(vals) > 1 else 1.0

    # Robustly limit the effect of extreme historical multipliers.
    center = 0.50 * median + 0.30 * recent_mean + 0.20 * min(mean, 5.0)
    predicted = max(1.01, min(center, 25.0))
    spread = max(0.35, min(2.5, 0.55 + volatility * 0.18))
    low = max(1.01, predicted - spread)
    high = min(50.0, predicted + spread)

    sample_factor = min(1.0, len(vals) / 30)
    confidence = int(max(15, min(85, 35 + sample_factor * 35 - min(volatility * 3, 25))))
    risk = "LOW" if volatility < 1.5 and confidence >= 60 else ("MEDIUM" if confidence >= 45 else "HIGH")

    return {
        "predicted": round(predicted, 2),
        "low": round(low, 2),
        "high": round(high, 2),
        "confidence": confidence,
        "risk": risk
    }

@app.context_processor
def inject_user():
    user = db.session.get(User, session.get("user_id")) if session.get("user_id") else None
    return {"current_user": user}

@app.route("/")
def index():
    results = Result.query.order_by(Result.created_at.desc()).limit(30).all()
    values = [r.multiplier for r in reversed(results)]
    prediction = calculate_prediction(values)
    return render_template("index.html", results=results, prediction=prediction)

@app.post("/api/predict")
def api_predict():
    results = Result.query.order_by(Result.created_at.desc()).limit(50).all()
    values = [r.multiplier for r in reversed(results)]
    prediction = calculate_prediction(values)
    p = Prediction(**prediction)
    db.session.add(p)
    db.session.commit()
    return jsonify(prediction)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        if len(username) < 3 or len(password) < 8:
            flash("Username must be 3+ characters and password 8+ characters.", "error")
            return redirect(url_for("register"))
        if User.query.filter_by(username=username).first():
            flash("Username already exists.", "error")
            return redirect(url_for("register"))
        user = User(username=username, password_hash=generate_password_hash(password))
        db.session.add(user)
        db.session.commit()
        session["user_id"] = user.id
        flash("Account created.", "success")
        return redirect(url_for("index"))
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username).first()
        if not user or not check_password_hash(user.password_hash, password):
            flash("Invalid username or password.", "error")
            return redirect(url_for("login"))
        session["user_id"] = user.id
        return redirect(url_for("admin" if user.is_admin else "index"))
    return render_template("auth.html", mode="login")

@app.get("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.get("/admin")
@admin_required
def admin():
    results = Result.query.order_by(Result.created_at.desc()).limit(100).all()
    users = User.query.order_by(User.created_at.desc()).limit(100).all()
    predictions = Prediction.query.order_by(Prediction.created_at.desc()).limit(50).all()
    return render_template("admin.html", results=results, users=users, predictions=predictions)

@app.post("/admin/results")
@admin_required
def add_result():
    try:
        multiplier = float(request.form.get("multiplier", "0"))
        if not (1.0 <= multiplier <= 100000):
            raise ValueError
    except ValueError:
        flash("Enter a valid multiplier >= 1.00.", "error")
        return redirect(url_for("admin"))
    db.session.add(Result(multiplier=multiplier))
    db.session.commit()
    return redirect(url_for("admin"))

@app.post("/admin/results/<int:result_id>/delete")
@admin_required
def delete_result(result_id):
    result = db.session.get(Result, result_id)
    if result:
        db.session.delete(result)
        db.session.commit()
    return redirect(url_for("admin"))

@app.post("/admin/users/<int:user_id>/toggle-admin")
@admin_required
def toggle_admin(user_id):
    user = db.session.get(User, user_id)
    current = db.session.get(User, session["user_id"])
    if user and user.id != current.id:
        user.is_admin = not user.is_admin
        db.session.commit()
    return redirect(url_for("admin"))

@app.get("/api/history")
def api_history():
    results = Result.query.order_by(Result.created_at.desc()).limit(50).all()
    return jsonify([{"multiplier": r.multiplier, "created_at": r.created_at.isoformat()} for r in reversed(results)])

@app.get("/health")
def health():
    return {"status": "ok"}

def initialize():
    with app.app_context():
        db.create_all()
        if not User.query.filter_by(username="admin").first():
            admin_password = os.environ.get("ADMIN_PASSWORD")
            if admin_password:
                user = User(
                    username="admin",
                    password_hash=generate_password_hash(admin_password),
                    is_admin=True
                )
                db.session.add(user)
                db.session.commit()

if __name__ == "__main__":
    initialize()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=True)
