# AviatorLab Predictor

A Flask + SQLAlchemy Aviator statistics website with:

- Responsive frontend
- User registration/login
- Admin dashboard
- Historical multiplier database
- Statistical estimate engine
- Prediction history
- JSON API
- SQLite locally
- PostgreSQL support in production
- Render deployment configuration

## Important

This is a statistical estimator. It does **not** hack Aviator, access a casino server, reveal a server seed, or guarantee the next multiplier. The game outcome remains controlled by the game's own system.

## Run locally

Python 3.13 is recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
```

Set an admin password:

Linux/macOS:
```bash
export ADMIN_PASSWORD="ChangeThisToAStrongPassword"
```

Windows PowerShell:
```powershell
$env:ADMIN_PASSWORD="ChangeThisToAStrongPassword"
```

Start:
```bash
python app.py
```

Open `http://127.0.0.1:5000`.

The first startup creates an `admin` account when `ADMIN_PASSWORD` is set.

## Render deployment

Render's current Flask quickstart uses a Python Web Service, `pip install -r requirements.txt` as the build command, and Gunicorn as the start command. See:
https://render.com/docs/deploy-flask

Create a GitHub repository and push this folder.

On Render:
1. New -> Web Service.
2. Connect the GitHub repository.
3. Runtime: Python.
4. Build command: `pip install -r requirements.txt`
5. Start command: `gunicorn app:app`
6. Add environment variables:
   - `SECRET_KEY` = a long random secret
   - `ADMIN_PASSWORD` = a strong admin password
   - `DATABASE_URL` = your PostgreSQL internal connection string

Render web services must listen on the platform port; Gunicorn handles this deployment setup.

For persistent production data, use PostgreSQL rather than local SQLite. Render provides managed PostgreSQL and documents connecting a web service to it:
https://render.com/docs/postgresql-creating-connecting

Render also offers free web services and Postgres for testing/hobby use, with limitations. Free web services can spin down after inactivity:
https://render.com/docs/free

## API

GET `/api/history` returns recent stored results.

POST `/api/predict` calculates and records a new statistical estimate.

GET `/health` is a health check.

## Production security

Before accepting real users:
- Set a strong random SECRET_KEY.
- Use a strong unique admin password.
- Add CSRF protection to all state-changing forms.
- Add rate limiting.
- Add email verification/password reset.
- Add database backups.
- Keep the disclaimer visible.
