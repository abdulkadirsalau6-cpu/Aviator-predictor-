const btn = document.getElementById("predictBtn");
if (btn) {
  btn.addEventListener("click", async () => {
    btn.disabled = true;
    btn.textContent = "CALCULATING...";
    try {
      const r = await fetch("/api/predict", {method:"POST"});
      const p = await r.json();
      document.getElementById("range").textContent = `${p.low}x – ${p.high}x`;
      document.getElementById("predicted").textContent = `${p.predicted}x`;
      document.getElementById("confidence").textContent = `${p.confidence}%`;
      document.getElementById("risk").textContent = p.risk;
    } catch(e) {
      alert("Could not generate estimate.");
    } finally {
      btn.disabled = false;
      btn.textContent = "GENERATE ESTIMATE";
    }
  });
}
